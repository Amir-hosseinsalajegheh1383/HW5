#include <stdio.h>
#include <string.h>
int main ()
{
    int n;
    printf("enter a number \n");
    scanf("%d",&n);
    char a[n];
    char b[n];
    char temp[n];
    int i,j,e;
    scanf("%s",&a);
    strcpy(b,a);
    for(j=0;j<(n/2);j++)
    {
        for(i=0;i<n;i++)
        {   
        if(b[i+1]==b[i])
        {
            b[i]='\0';
            b[i+1]='\0';
            for(e=i+2;e<n;e++)
            {
                b[e-2]=b[e];
                b[e]='\0';
            }
        }
        }
        printf("\n");
         strcpy(temp,b);
         strcpy(b,temp);
         printf("%s\n",b);
    }
    return 0;
}