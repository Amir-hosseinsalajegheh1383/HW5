//40223039-amir hossein salajegheh
#include <stdio.h>
#include <string.h>
int main ()
{
    int n;
    printf("enter a number(n) after that write a word by n letters with out space\n");
    scanf("%d",&n);
    char a[n];
    char b[n];
    char temp[n];
    int i,j,e,x=0;
    scanf("%s",&a);
    strcpy(b,a);
    for(i=0;i<n;i++)
    {
    if(b[i]==b[i+1])
    {
        x++;
        b[i]='\0';
        b[i+1]='\0';
        for( int y=i+2;y<n;y++)
            {
                b[y-2]=b[y];
                b[y]='\0';
            }
    }
    }
    strcpy(b,a);
    for(j=0;j<x;j++)
    {
        for(i=0;i<n;i++)
        {   
        if(b[i+1]==b[i])
        {
            b[i]='\0';
            b[i+1]='\0';
            for(e=i+2;e<n;e++)
            {
                b[e-2]=b[e];
                b[e]='\0';
            }
        }
        }
        printf("\n");
         strcpy(temp,b);
         strcpy(b,temp);
         printf("%s\n",b);
    }
    
    return 0;
}